import { Component,OnInit  } from '@angular/core';
import { TranslationService } from 'src/app/services/translation.service';

@Component({
  selector: 'app-names-of-allah',
  templateUrl: './names-of-allah.component.html',
  styleUrls: ['./names-of-allah.component.scss']
})
export class NamesOfAllahComponent implements OnInit {
  
  selectedItem: any;
  name: any;
  number: any;
  meaning: any;
  explanation: any;
  allahNames: { name: string; number: string; }[] = [
    { name: "1. Ar-Rahman", number: "1" },
    { name: "2. Ar-Rahim", number: "2" },
    { name: "3. Al-Malik", number: "3" },
    { name: "4. Al-Quddus", number: "4" },
    { name: "5. As-Salam", number: "5" },
    { name: "6. Al-Mu'min", number: "6" },
    { name: "7. Al-Muhaymin", number: "7" },
    { name: "8. Al-Aziz", number: "8" },
    { name: "9. Al-Jabbar", number: "9" },
    { name: "10. Al-Mutakabbir", number: "10" },
    { name: "11. Al-Khaliq", number: "11" },
    { name: "12. Al-Bari", number: "12" },
    { name: "13. Al-Musawwir", number: "13" },
    { name: "14. Al-Ghaffar", number: "14" },
    { name: "15. Al-Qahhar", number: "15" },
    { name: "16. Al-Wahhab", number: "16" },
    { name: "17. Ar-Razzaq", number: "17" },
    { name: "18. Al-Fattah", number: "18" },
    { name: "19. Al-Alim", number: "19" },
    { name: "20. Al-Qabid", number: "20" },
    { name: "21. Al-Basit", number: "21" },
    { name: "22. Al-Khafid", number: "22" },
    { name: "23. Ar-Rafi", number: "23" },
    { name: "24. Al-Mu'izz", number: "24" },
    { name: "25. Al-Mudhill", number: "25" },
    { name: "26. As-Sami", number: "26" },
    { name: "27. Al-Basir", number: "27" },
    { name: "28. Al-Hakam", number: "28" },
    { name: "29. Al-Adl", number: "29" },
    { name: "30. Al-Latif", number: "30" },
    { name: "31. Al-Khabir", number: "31" },
    { name: "32. Al-Halim", number: "32" },
    { name: "33. Al-Azim", number: "33" },
    { name: "34. Al-Ghafur", number: "34" },
    { name: "35. Ash-Shakur", number: "35" },
    { name: "36. Al-Ali", number: "36" },
    { name: "37. Al-Kabir", number: "37" },
    { name: "38. Al-Hafiz", number: "38" },
    { name: "39. Al-Muqit", number: "39" },
    { name: "40. Al-Hasib", number: "40" },
    { name: "41. Al-Jalil", number: "41" },
    { name: "42. Al-Karim", number: "42" },
    { name: "43. Ar-Raqib", number: "43" },
    { name: "44. Al-Mujib", number: "44" },
    { name: "45. Al-Wasi", number: "45" },
    { name: "46. Al-Hakim", number: "46" },
    { name: "47. Al-Wadud", number: "47" },
    { name: "48. Al-Majid", number: "48" },
    { name: "49. Al-Ba'ith", number: "49" },
    { name: "50. Ash-Shahid", number: "50" },
    { name: "51. Al-Haqq", number: "51" },
    { name: "52. Al-Wakil", number: "52" },
    { name: "53. Al-Qawi", number: "53" },
    { name: "54. Al-Matin", number: "54" },
    { name: "55. Al-Wali", number: "55" },
    { name: "56. Al-Hamid", number: "56" },
    { name: "57. Al-Muhsi", number: "57" },
    { name: "58. Al-Mubdi", number: "58" },
    { name: "59. Al-Mu'id", number: "59" },
    { name: "60. Al-Muhyi", number: "60" },
    { name: "61. Al-Mumit", number: "61" },
    { name: "62. Al-Hayy", number: "62" },
    { name: "63. Al-Qayyum", number: "63" },
    { name: "64. Al-Wajid", number: "64" },
    { name: "65. Al-Majid", number: "65" },
    { name: "66. Al-Wahid", number: "66" },
    { name: "67. As-Samad", number: "67" },
    { name: "68. Al-Qadir", number: "68" },
    { name: "69. Al-Muqtadir", number: "69" },
    { name: "70. Al-Muqaddim", number: "70" },
    { name: "71. Al-Mu'akhkhir", number: "71" },
    { name: "72. Al-Awwal", number: "72" },
    { name: "73. Al-Akhir", number: "73" },
    { name: "74. Az-Zahir", number: "74" },
    { name: "75. Al-Batin", number: "75" },
    { name: "76. Al-Wali", number: "76" },
    { name: "77. Al-Muta'ali", number: "77" },
    { name: "78. Al-Barr", number: "78" },
    { name: "79. At-Tawwab", number: "79" },
    { name: "80. Al-Muntaqim", number: "80" },
    { name: "81. Al-Afuww", number: "81" },
    { name: "82. Ar-Ra'uf", number: "82" },
    { name: "83. Malik al-Mulk", number: "83" },
    { name: "84. Dhu-l-Jalal wa-l-Ikram", number: "84" },
    { name: "85. Al-Muqsit", number: "85" },
    { name: "86. Al-Jami", number: "86" },
    { name: "87. Al-Ghani", number: "87" },
    { name: "88. Al-Mughni", number: "88" },
    { name: "89. Al-Mani", number: "89" },
    { name: "90. Ad-Darr", number: "90" },
    { name: "91. An-Nafi", number: "91" },
    { name: "92. An-Nur", number: "92" },
    { name: "93. Al-Hadi", number: "93" },
    { name: "94. Al-Badi", number: "94" },
    { name: "95. Al-Baqi", number: "95" },
    { name: "96. Al-Warith", number: "96" },
    { name: "97. Ar-Rashid", number: "97" },
    { name: "98. As-Sabur", number: "98" },
    { name: "99. Allah", number: "99" },
  ];
  arabicword: any;
  languagevalues: string = 'en';

  constructor(private translationService: TranslationService) {}

  onDropdownChange(event: any) {
    this.languagevalues = event.target.value;
    this.translationService.setLanguage(this.languagevalues);
  }

 
  

  ngOnInit() {
   
    this.selectedItem = this.allahNames[0];
    this.updateValues();
    const fakeEvent = {
      target: {
        value: 'en' // Replace 'en' with the desired value
      }
    };

    this.onDropdownChange(fakeEvent);
  }

  updateValues() {
    if (this.selectedItem.number === '1') {
      this.arabicword = 'ٱلْرَّحْمَـانُ'
      this.name = 'Ar-Rahman';
      this.number = '	1';
      this.meaning = 'The Compassionate or Most Gracious ';
      this.explanation = 'Allah is infinitely compassionate and merciful towards His creation';
    } else if (this.selectedItem.number === '2') {
      this.arabicword = 'الرحيم'
      this.name = 'Ar-Rahim';
      this.number = '2';
      this.meaning = 'The Most Merciful';
      this.explanation = "Allah's mercy is abundant and continuous, specifically for the believers.";
    }
    else if (this.selectedItem.number === '3') {
      this.arabicword = 'الملك'
      this.name = 'Al-Malik';
      this.number = '3';
      this.meaning = 'The Sovereign Lord';
      this.explanation = "Allah is the ultimate ruler and owner of everything in the universe..";
    }else if (this.selectedItem.number === '4') {
      this.arabicword = 'القدوس'
      this.name = 'Al-Quddus';
      this.number = '4';
      this.meaning = 'The Holy';
      this.explanation = "Allah is pure and free from any imperfections.";
    }else if (this.selectedItem.number === '5') {
      this.arabicword = 'السلام'
      this.name = 'As-Salam';
      this.number = '5';
      this.meaning = 'The Source of Peace';
      this.explanation = "Allah is the giver of peace and tranquility.";
    }else if (this.selectedItem.number === '6') {
      this.arabicword = 'المؤمن'
      this.name = "Al-Mu'min";
      this.number = '6';
      this.meaning = 'The Bestower of Faith';
      this.explanation = "Allah is the one who grants faith and security.";
    }else if (this.selectedItem.number === '7') {
      this.arabicword = 'المهيمن'
      this.name = 'Al-Muhaymin';
      this.number = '7';
      this.meaning = 'The Guardian';
      this.explanation = "Allah is the protector and guardian of all.";
    }else if (this.selectedItem.number === '8') {
      this.arabicword = 'العزيز'
      this.name = 'Al-Aziz';
      this.number = '8';
      this.meaning = 'The Almighty';
      this.explanation = "Allah is powerful and mighty.";
    }else if (this.selectedItem.number === '9') {
      this.arabicword = 'الجبار'
      this.name = 'Al-Jabbar';
      this.number = '9';
      this.meaning = 'The Compellerl';
      this.explanation = "Allah has the power to enforce His will.";
    }else if (this.selectedItem.number === '10') {
      this.arabicword = 'المتكبر'
      this.name = 'Al-Mutakabbir';
      this.number = '10';
      this.meaning = 'The Majestic';
      this.explanation = "Allah is the ultimate source of greatness and pride.";
    }else if (this.selectedItem.number === '11') {
      this.arabicword = 'ٱلْخَالِقُ'
      this.name = 'Al-Khaliq';
      this.number = '	11';
      this.meaning = 'The Creator ';
      this.explanation = 'Allah is the originator and designer of all existence.';
    }
    else if (this.selectedItem.number === '12') {
      this.arabicword = 'ٱلْبَارِئُ'
      this.name = 'Al-Bari';
      this.number = '12';
      this.meaning = 'The Evolver';
      this.explanation = "Allah shapes and forms everything according to His plan.";
    }
    else if (this.selectedItem.number === '13') {
      this.arabicword = 'ٱلْمُصَوِّرُ'
      this.name = 'Al-Musawwir';
      this.number = '13';
      this.meaning = 'The Fashioner';
      this.explanation = "Allah fashions His creation with perfect design.";
    }else if (this.selectedItem.number === '14') {
      this.arabicword = 'ٱلْغَفَّارُ'
      this.name = 'Al-Ghaffar';
      this.number = '14';
      this.meaning = 'The Forgiving';
      this.explanation = "Allah is the pardoner of sins..";
    }else if (this.selectedItem.number === '15') {
      this.arabicword = 'ٱلْقَهَّارُ'
      this.name = 'Al-Qahhar';
      this.number = '15';
      this.meaning = 'The Subduer';
      this.explanation = "Allah has absolute control over all..";
    }else if (this.selectedItem.number === '16') {
      this.arabicword = 'ٱلْوَهَّابُ'
      this.name = "Al-wahhaab";
      this.number = '16';
      this.meaning = 'The Bestower';
      this.explanation = "Allah is the giver of gifts and blessings.";
    }else if (this.selectedItem.number === '17') {
      this.arabicword = 'ٱلْرَّزَّاقُ'
      this.name = 'Ar-Razzaaq';
      this.number = '17';
      this.meaning = 'The Provide';
      this.explanation = "Allah sustains and nourishes His creation.";
    }else if (this.selectedItem.number === '18') {
      this.arabicword = 'ٱلْفَتَّاحُ'
      this.name = 'Al-fattah';
      this.number = '18';
      this.meaning = 'The Opener';
      this.explanation = "Allah opens doors and grants victory.";
    }else if (this.selectedItem.number === '19') {
      this.arabicword = 'ٱلْعَلِيمُ'
      this.name = 'Al-Alim';
      this.number = '19';
      this.meaning = 'The Knower of All';
      this.explanation = "Allah has complete knowledge of everything.";
    }else if (this.selectedItem.number === '20') {
      this.arabicword = 'ٱلْقَابِضُ'
      this.name = 'Al-Qaabid';
      this.number = '20';
      this.meaning = 'The Withholder';
      this.explanation = "Allah has the power to restrain and hold back.";
    }    if (this.selectedItem.number === '21') {
      this.arabicword = 'ٱلْبَاسِطُ'
      this.name = 'Al-Basit';
      this.number = '	21';
      this.meaning = 'The Extender ';
      this.explanation = 'Allah expands and provides without limit.';
    } else if (this.selectedItem.number === '22') {
      this.arabicword = 'ٱلْخَافِضُ'
      this.name = 'Al-Khafid';
      this.number = '22';
      this.meaning = 'The Abaser';
      this.explanation = "Allah lowers and humbles whom He wills.";
    }
    else if (this.selectedItem.number === '23') {
      this.arabicword = 'ٱلْرَّافِعُ'
      this.name = 'Ar-Rafi ';
      this.number = '23';
      this.meaning = 'The Exalter';
      this.explanation = "Allah raises and elevates whom He wills.";
    }else if (this.selectedItem.number === '24') {
      this.arabicword = 'ٱلْمُعِزُّ'
      this.name = "Al-Mu'izz";
      this.number = '24';
      this.meaning = 'The Giver of Honor';
      this.explanation = "Allah grants honor and dignity.";
    }else if (this.selectedItem.number === '25') {
      this.arabicword = 'ٱلْمُذِلُّ'
      this.name = 'Al-Mudhill';
      this.number = '25';
      this.meaning = 'The Giver of Dishonor';
      this.explanation = "Allah can humble those who oppose Him.";
    }else if (this.selectedItem.number === '26') {
      this.arabicword = 'ٱلْسَّمِيعُ'
      this.name = "As-Samee";
      this.number = '26';
      this.meaning = 'The All-Hearing';
      this.explanation = "Allah hears all sounds and prayers.";
    }else if (this.selectedItem.number === '27') {
      this.arabicword = 'ٱلْبَصِيرُ'
      this.name = 'Al-Basir';
      this.number = '27';
      this.meaning = 'The All-Seeing';
      this.explanation = "Allah sees everything, even the hidden.";
    }else if (this.selectedItem.number === '28') {
      this.arabicword = 'ٱلْحَكَمُ'
      this.name = 'Al-hakam';
      this.number = '28';
      this.meaning = 'The Judge';
      this.explanation = "Allah is the ultimate arbiter of justice.";
    }else if (this.selectedItem.number === '29') {
      this.arabicword = 'ٱلْعَدْلُ'
      this.name = 'Al-Adl';
      this.number = '29';
      this.meaning = 'The Just';
      this.explanation = "Allah is perfectly fair in His judgments.";
    }else if (this.selectedItem.number === '30') {
      this.arabicword = 'ٱلْلَّطِيفُ'
      this.name = 'Al-Latif';
      this.number = '30';
      this.meaning = 'The Subtle One';
      this.explanation = "Allah's kindness is subtle and gentle.";
    }else if (this.selectedItem.number === '31') {
      this.arabicword = 'ٱلْخَبِيرُ'
      this.name = 'Al-Khabir';
      this.number = '	31';
      this.meaning = 'The All-Aware ';
      this.explanation = 'Allah is fully aware of all matters';
    }
    else if (this.selectedItem.number === '32') {
      this.arabicword = 'ٱلْحَلِيمُ'
      this.name = 'Al-Halim';
      this.number = '32';
      this.meaning = 'The Forbearingl';
      this.explanation = "Allah is patient and slow to anger.";
    }
    else if (this.selectedItem.number === '33') {
      this.arabicword = 'ٱلْعَظِيمُ'
      this.name = 'Al-Azim';
      this.number = '33';
      this.meaning = 'The Magnificent';
      this.explanation = "Allah's greatness is beyond comprehension.";
    }else if (this.selectedItem.number === '34') {
      this.arabicword = 'ٱلْغَفُورُ'
      this.name = 'Al-Ghafur';
      this.number = '34';
      this.meaning = 'The All-Forgiving';
      this.explanation = " Allah forgives sins abundantly.";
    }else if (this.selectedItem.number === '35') {
      this.arabicword = 'ٱلْشَّكُورُ'
      this.name = 'Ash-Shakur';
      this.number = '35';
      this.meaning = 'The Appreciative';
      this.explanation = "Allah appreciates and rewards good deeds.";
    }else if (this.selectedItem.number === '36') {
      this.arabicword = 'ٱلْعَلِيُّ'
      this.name = "(Al-Ali";
      this.number = '36';
      this.meaning = 'The Most High:';
      this.explanation = "Allah is exalted above all.";
    }else if (this.selectedItem.number === '37') {
      this.arabicword = 'ٱلْكَبِيرُ'
      this.name = 'Al-Kabir';
      this.number = '37';
      this.meaning = 'The Most Great';
      this.explanation = "Allah's greatness is limitless.";
    }else if (this.selectedItem.number === '38') {
      this.arabicword = 'ٱلْحَفِيظُ'
      this.name = 'Al-Hafiz';
      this.number = '38';
      this.meaning = 'The Preserver';
      this.explanation = " Allah safeguards His creation.";
    }else if (this.selectedItem.number === '39') {
      this.arabicword = 'ٱلْمُقِيتُ'
      this.name = 'Al-Muqit';
      this.number = '39';
      this.meaning = 'The Nourisher';
      this.explanation = "Allah provides for all His creatures.";
    }else if (this.selectedItem.number === '40') {
      this.arabicword = 'ٱلْحَسِيبُ'
      this.name = 'Al-Hasib';
      this.number = '40';
      this.meaning = 'The Reckoner';
      this.explanation = "Allah takes account of all deeds.";
    }
  }
}
